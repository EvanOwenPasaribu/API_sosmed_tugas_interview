## Init LARAVEL
php artisan

## About API

API ini adalah API Sosmed sederhana, menggunakan Laravel Passport Sebagai Authentikasi User, API ini bisa digunakan untuk : 
1 Login 
2 Register
3 Mengambil semua data User termasuk follower dan following nya.
4 Follow / Unfollow User lain
5 Mengambil semua data postingan user termasuk like dan komentarnya.
6 Menambahkan Postingan
7 Menghapus Postingan
8 Like / Unlike Postingan
9 Mengomentasi Postingan

Untuk melakukan point nomor 3 sampai nomor 9, itu membutuhkan Authorization Bearer<token>
Jadi token bisa kita dapatkan setelah melakukan request login atau register.





